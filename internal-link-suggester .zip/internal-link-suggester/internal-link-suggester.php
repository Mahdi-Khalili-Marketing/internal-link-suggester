<?php
/**
 * Plugin Name: Internal Link Suggester
 * Description: Suggests semantically relevant internal links using OpenAI embeddings + GPT-4o. Review and 1-click apply. (PHP port of the n8n flow.)
 * Version: 1.0.0
 * Author: Mahdi Khalili
 * License: GPL-2.0+
 * Text Domain: ils
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ILS_VERSION', '1.0.0' );
define( 'ILS_PLUGIN_FILE', __FILE__ );
define( 'ILS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'ILS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Tuning values — kept identical to the original n8n flow.
define( 'ILS_SIMILARITY_THRESHOLD', 0.45 );
define( 'ILS_CANDIDATE_COUNT', 5 );   // candidates passed to the AI
define( 'ILS_MAX_SUGGESTIONS', 3 );   // max links AI may return
define( 'ILS_MIN_WORDS', 120 );       // skip thin posts when embedding
define( 'ILS_MAX_EMBED_CHARS', 1024 );
define( 'ILS_BATCH_SIZE', 7 );        // posts processed per "Find links" run

require_once ILS_PLUGIN_DIR . 'includes/class-ils-db.php';
require_once ILS_PLUGIN_DIR . 'includes/class-ils-openai.php';
require_once ILS_PLUGIN_DIR . 'includes/class-ils-embeddings.php';
require_once ILS_PLUGIN_DIR . 'includes/class-ils-suggester.php';
require_once ILS_PLUGIN_DIR . 'includes/class-ils-admin.php';

register_activation_hook( __FILE__, array( 'ILS_DB', 'install' ) );

add_action( 'init', function () {
	load_plugin_textdomain( 'ils', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );

add_action( 'plugins_loaded', function () {
	ILS_Admin::instance();
} );
