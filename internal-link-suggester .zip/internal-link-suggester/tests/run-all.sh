#!/usr/bin/env bash
# Run every test suite. Requires php on PATH.
set -e
DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "== php lint =="
for f in "$DIR"/internal-link-suggester.php "$DIR"/includes/*.php; do
	php -l "$f"
done

echo "== pure logic =="
php "$DIR/tests/run.php"

echo "== orchestration =="
php "$DIR/tests/run-orchestration.php"
