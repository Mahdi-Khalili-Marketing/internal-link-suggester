<?php
/**
 * Plain-PHP test runner for the plugin's pure logic. Run:  php tests/run.php
 */
require __DIR__ . '/bootstrap.php';
require dirname( __DIR__ ) . '/includes/class-ils-admin.php';

$passed = 0;
$failed = 0;

function check( $label, $got, $want ) {
	global $passed, $failed;
	$ok = ( $got === $want );
	if ( $ok ) {
		++$passed;
		echo "  ok   {$label}\n";
	} else {
		++$failed;
		echo "  FAIL {$label}\n";
		echo '       got:  ' . var_export( $got, true ) . "\n";
		echo '       want: ' . var_export( $want, true ) . "\n";
	}
}

function check_true( $label, $got ) {
	check( $label, (bool) $got, true );
}

echo "== normalize_url ==\n";
check( 'lowercase + strip www + trailing slash', ILS_Suggester::normalize_url( 'https://www.OABeans.com/Foo/' ), 'https://oabeans.com/foo' );
check( 'drop query + fragment', ILS_Suggester::normalize_url( 'https://oabeans.com/foo?x=1#frag' ), 'https://oabeans.com/foo' );
check( 'fragment-only -> empty', ILS_Suggester::normalize_url( '#section' ), '' );
check( 'empty -> empty', ILS_Suggester::normalize_url( '' ), '' );
check( 'no host -> empty', ILS_Suggester::normalize_url( '/relative/path' ), '' );

echo "== get_base_url ==\n";
check( 'strip www, scheme+host only', ILS_Suggester::get_base_url( 'https://www.oabeans.com/post/123' ), 'https://oabeans.com' );
check( 'garbage -> home_url fallback', ILS_Suggester::get_base_url( 'notaurl' ), 'https://example.com' );

echo "== extract_links ==\n";
$html  = '<a href="https://www.oabeans.com/a/">A</a>'
	. '<a href="/b">B</a>'
	. '<a href="#x">X</a>'
	. '<a href="mailto:a@b.com">M</a>'
	. '<a href="tel:123">T</a>'
	. '<a href="https://other.com/c">C</a>'
	. '<a href="relative-no-slash">R</a>';
$links = ILS_Suggester::extract_links( $html, 'https://oabeans.com' );
sort( $links );
check( 'only http + root-relative, normalized', $links, array( 'https://oabeans.com/a', 'https://oabeans.com/b', 'https://other.com/c' ) );

echo "== extract_anchors ==\n";
$ah = ILS_Suggester::extract_anchors( '<p>Read <a href="/b">Click <b>here</b> now</a>!</p>', 'https://oabeans.com' );
check( 'one anchor extracted', count( $ah ), 1 );
check( 'anchor url normalized', $ah[0]['url'], 'https://oabeans.com/b' );
check( 'anchor inner tags stripped', $ah[0]['anchor'], 'Click here now' );

echo "== cosine ==\n";
check( 'identical -> 1.0', round( ILS_Suggester::cosine( '[1,2,3]', '[1,2,3]' ), 6 ), 1.0 );
check( 'orthogonal -> 0', ILS_Suggester::cosine( '[1,0]', '[0,1]' ), 0.0 );
check( 'length mismatch -> 0', ILS_Suggester::cosine( '[1,2,3]', '[1,2]' ), 0.0 );
check( 'zero vector -> 0', ILS_Suggester::cosine( '[0,0]', '[1,1]' ), 0.0 );
check( 'bad json -> 0', ILS_Suggester::cosine( 'not json', '[1,1]' ), 0.0 );

echo "== clean_html ==\n";
check( 'strip tags + collapse ws', ILS_Embeddings::clean_html( "<p>Hello   <b>world</b>\n\nthere</p>" ), 'Hello world there' );

echo "== apply helpers (reflection) ==\n";
$admin = ( new ReflectionClass( 'ILS_Admin' ) )->newInstanceWithoutConstructor();

// setAccessible() is a no-op since PHP 8.1 — private methods are reachable via reflection directly.
$ref_replace = new ReflectionMethod( 'ILS_Admin', 'replace_first_unlinked' );
$ref_inside  = new ReflectionMethod( 'ILS_Admin', 'is_inside_anchor' );

// First occurrence replaced, later ones untouched.
$replaced = false;
$args     = array( 'foo bar foo baz', 'foo', '<a href="x">foo</a>', &$replaced );
$out      = $ref_replace->invokeArgs( $admin, $args );
check( 'replaces first occurrence only', $out, '<a href="x">foo</a> bar foo baz' );
check_true( 'replaced flag set', $replaced );

// Occurrence already inside an <a> is skipped; next free one is used.
$replaced = false;
$content  = '<a href="/x">foo</a> middle foo end';
$args     = array( $content, 'foo', '<a href="/new">foo</a>', &$replaced );
$out      = $ref_replace->invokeArgs( $admin, $args );
check( 'skips anchor-wrapped occurrence', $out, '<a href="/x">foo</a> middle <a href="/new">foo</a> end' );

// No match -> replaced stays false.
$replaced = false;
$args     = array( 'nothing here', 'foo', '<a>foo</a>', &$replaced );
$ref_replace->invokeArgs( $admin, $args );
check( 'no match leaves replaced false', $replaced, false );

// is_inside_anchor pinpoints offsets.
$h   = '<a href="/x">foo</a> foo';
$in  = strpos( $h, 'foo' );        // inside the anchor
$out2 = strpos( $h, 'foo', $in + 3 ); // the free one
check( 'pos inside anchor -> true', $ref_inside->invoke( $admin, $h, $in ), true );
check( 'pos outside anchor -> false', $ref_inside->invoke( $admin, $h, $out2 ), false );

echo "\n----------------------------\n";
echo "PASSED: {$passed}   FAILED: {$failed}\n";
exit( $failed > 0 ? 1 : 0 );
