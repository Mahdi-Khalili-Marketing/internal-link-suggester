<?php
/**
 * Orchestration test bootstrap: stubs WP + provides in-memory mocks of ILS_DB and
 * ILS_OpenAI so ILS_Suggester::run_for_post() / run_batch() can run with no DB, no WP, no API key.
 *
 * The real ILS_DB / ILS_OpenAI are never required here, so these mock class definitions win.
 */

define( 'ABSPATH', __DIR__ . '/' );

define( 'ILS_SIMILARITY_THRESHOLD', 0.45 );
define( 'ILS_CANDIDATE_COUNT', 5 );
define( 'ILS_MAX_SUGGESTIONS', 3 );
define( 'ILS_MIN_WORDS', 120 );
define( 'ILS_MAX_EMBED_CHARS', 1024 );
define( 'ILS_BATCH_SIZE', 7 );

/* ---------- WP stubs ---------- */

function __( $text, $domain = 'default' ) {
	return $text;
}
function wp_parse_url( $url, $component = -1 ) {
	return parse_url( $url, $component );
}
function home_url( $path = '' ) {
	return 'https://example.com' . $path;
}

class WP_Error {
	public $code;
	public $message;
	public function __construct( $code = '', $message = '' ) {
		$this->code    = $code;
		$this->message = $message;
	}
	public function get_error_message() {
		return $this->message;
	}
}
function is_wp_error( $thing ) {
	return $thing instanceof WP_Error;
}

$GLOBALS['__posts'] = array();
function get_post( $id ) {
	return isset( $GLOBALS['__posts'][ $id ] ) ? $GLOBALS['__posts'][ $id ] : null;
}
function ils_register_post( $id, $content ) {
	$GLOBALS['__posts'][ $id ] = (object) array(
		'ID'            => $id,
		'post_content'  => $content,
		'post_modified' => '2026-01-01 00:00:00',
	);
}

/* ---------- Mock ILS_DB (in-memory) ---------- */

class ILS_DB {
	public static $embeddings  = array(); // post_id => row
	public static $suggestions = array();

	public static function reset() {
		self::$embeddings  = array();
		self::$suggestions = array();
		$GLOBALS['__posts'] = array();
	}

	public static function add_embedding( $post_id, $title, $url, $plain, $vector ) {
		self::$embeddings[ $post_id ] = array(
			'post_id'    => $post_id,
			'post_title' => $title,
			'post_url'   => $url,
			'plain_text' => $plain,
			'embedding'  => wp_json_encode_compat( $vector ),
		);
	}

	public static function get_embedding( $post_id ) {
		return isset( self::$embeddings[ $post_id ] ) ? self::$embeddings[ $post_id ] : null;
	}
	public static function get_all_embeddings() {
		return array_values( self::$embeddings );
	}
	public static function get_embedded_post_ids() {
		return array_map( 'intval', array_keys( self::$embeddings ) );
	}
	public static function get_processed_post_ids() {
		$ids = array();
		foreach ( self::$suggestions as $s ) {
			$ids[ (int) $s['source_post_id'] ] = true;
		}
		return array_keys( $ids );
	}
	public static function insert_suggestion( $row ) {
		self::$suggestions[] = $row;
		return count( self::$suggestions );
	}
}

/* ---------- Mock ILS_OpenAI ---------- */

class ILS_OpenAI {
	public static $next_response = '';   // string (JSON) or WP_Error
	public static $chat_calls    = 0;

	public static function reset() {
		self::$next_response = '';
		self::$chat_calls    = 0;
	}
	public static function chat_json( $messages ) {
		++self::$chat_calls;
		return self::$next_response;
	}
	public static function embed( $text ) {
		return array( 0.1, 0.1, 0.1 );
	}
}

function wp_json_encode_compat( $data ) {
	return json_encode( $data );
}

require_once dirname( __DIR__ ) . '/includes/class-ils-suggester.php';
