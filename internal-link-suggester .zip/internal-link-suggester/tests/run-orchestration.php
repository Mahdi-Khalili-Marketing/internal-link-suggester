<?php
/**
 * Orchestration tests for ILS_Suggester::run_for_post() and run_batch().
 * Run:  php tests/run-orchestration.php
 */
require __DIR__ . '/bootstrap-mock.php';

$passed = 0;
$failed = 0;

function check( $label, $got, $want ) {
	global $passed, $failed;
	if ( $got === $want ) {
		++$passed;
		echo "  ok   {$label}\n";
	} else {
		++$failed;
		echo "  FAIL {$label}\n";
		echo '       got:  ' . var_export( $got, true ) . "\n";
		echo '       want: ' . var_export( $want, true ) . "\n";
	}
}

/** Seed a 4-post corpus: A,B,C very similar; D orthogonal (no candidates). */
function seed_corpus() {
	ILS_DB::reset();
	ILS_OpenAI::reset();
	ILS_DB::add_embedding( 1, 'Post A', 'https://oabeans.com/a', 'We love great coffee here. More text.', array( 1, 0, 0 ) );
	ILS_DB::add_embedding( 2, 'Post B', 'https://oabeans.com/b', 'Coffee beans content.', array( 0.9, 0.1, 0 ) );
	ILS_DB::add_embedding( 3, 'Post C', 'https://oabeans.com/c', 'Coffee roast content.', array( 0.8, 0.2, 0 ) );
	ILS_DB::add_embedding( 4, 'Post D', 'https://oabeans.com/d', 'Unrelated topic entirely.', array( 0, 1, 0 ) );
	// A already links to C -> C must be excluded as a candidate.
	ils_register_post( 1, '<p>We love great coffee here. <a href="https://oabeans.com/c">see c</a></p>' );
	ils_register_post( 2, '<p>Plain B content, no links.</p>' );
	ils_register_post( 3, '<p>Plain C content, no links.</p>' );
	ils_register_post( 4, '<p>Plain D content, no links.</p>' );
}

$valid_resp = '{"suggestions":[{"anchorText":"great coffee","link":"https://oabeans.com/b","reason":"adds value","contextualSentence":"We love great coffee here."}]}';

echo "== run_for_post: happy path, excludes self/linked/below-threshold ==\n";
seed_corpus();
ILS_OpenAI::$next_response = $valid_resp;
$r = ILS_Suggester::run_for_post( 1 );
check( 'returns 1 saved suggestion', $r, 1 );
check( 'AI was called once', ILS_OpenAI::$chat_calls, 1 );
check( 'one suggestion stored', count( ILS_DB::$suggestions ), 1 );
$s = ILS_DB::$suggestions[0];
check( 'source post id', $s['source_post_id'], 1 );
check( 'link target is B', $s['link'], 'https://oabeans.com/b' );
check( 'anchor text', $s['anchor_text'], 'great coffee' );
check( 'status pending', $s['status'], 'pending' );

echo "== run_for_post: no candidates -> 0, AI not called ==\n";
seed_corpus();
ILS_OpenAI::$next_response = $valid_resp;
$r = ILS_Suggester::run_for_post( 4 ); // D orthogonal to all
check( 'returns 0', $r, 0 );
check( 'AI never called', ILS_OpenAI::$chat_calls, 0 );
check( 'nothing stored', count( ILS_DB::$suggestions ), 0 );

echo "== run_for_post: malformed AI JSON -> 0 saved ==\n";
seed_corpus();
ILS_OpenAI::$next_response = 'not json {';
$r = ILS_Suggester::run_for_post( 1 );
check( 'returns 0 on bad json', $r, 0 );
check( 'AI was called', ILS_OpenAI::$chat_calls, 1 );
check( 'nothing stored', count( ILS_DB::$suggestions ), 0 );

echo "== run_for_post: suggestion missing required field -> filtered ==\n";
seed_corpus();
ILS_OpenAI::$next_response = '{"suggestions":[{"anchorText":"x","contextualSentence":"y"}]}'; // no link
$r = ILS_Suggester::run_for_post( 1 );
check( 'returns 0 when link missing', $r, 0 );
check( 'nothing stored', count( ILS_DB::$suggestions ), 0 );

echo "== run_for_post: post without embedding -> WP_Error ==\n";
seed_corpus();
$r = ILS_Suggester::run_for_post( 999 );
check( 'is WP_Error', is_wp_error( $r ), true );

echo "== run_for_post: AI transport error propagates ==\n";
seed_corpus();
ILS_OpenAI::$next_response = new WP_Error( 'ils_chat_failed', 'boom' );
$r = ILS_Suggester::run_for_post( 1 );
check( 'returns WP_Error', is_wp_error( $r ), true );
check( 'error message', $r->get_error_message(), 'boom' );

echo "== run_batch: processes only unprocessed, aggregates ==\n";
ILS_DB::reset();
ILS_OpenAI::reset();
// 3 mutually-similar posts, no existing links.
ILS_DB::add_embedding( 1, 'A', 'https://oabeans.com/a', 'aaa', array( 1, 0, 0 ) );
ILS_DB::add_embedding( 2, 'B', 'https://oabeans.com/b', 'bbb', array( 0.9, 0.1, 0 ) );
ILS_DB::add_embedding( 3, 'C', 'https://oabeans.com/c', 'ccc', array( 0.8, 0.2, 0 ) );
ils_register_post( 1, '<p>aaa no links</p>' );
ils_register_post( 2, '<p>bbb no links</p>' );
ils_register_post( 3, '<p>ccc no links</p>' );
ILS_OpenAI::$next_response = $valid_resp;
$summary = ILS_Suggester::run_batch();
check( 'processed 3 posts', $summary['posts'], 3 );
check( 'found 3 suggestions', $summary['suggestions'], 3 );
check( 'no errors', $summary['errors'], array() );
check( 'AI called 3x', ILS_OpenAI::$chat_calls, 3 );

echo "== run_batch: already-processed posts are skipped ==\n";
// Suggestions from previous run mark posts 1,2,3 processed -> next batch finds nothing.
$summary2 = ILS_Suggester::run_batch();
check( 'no posts left', $summary2['posts'], 0 );
check( 'no new suggestions', $summary2['suggestions'], 0 );

echo "\n----------------------------\n";
echo "PASSED: {$passed}   FAILED: {$failed}\n";
exit( $failed > 0 ? 1 : 0 );
