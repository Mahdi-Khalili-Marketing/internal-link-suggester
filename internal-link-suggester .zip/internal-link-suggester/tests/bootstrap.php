<?php
/**
 * Minimal bootstrap so the plugin's pure-logic methods can run under plain PHP CLI,
 * without a full WordPress install. Stubs only the WP functions those methods touch.
 */

define( 'ABSPATH', __DIR__ . '/' );

// Tuning constants (mirror the main plugin file).
define( 'ILS_SIMILARITY_THRESHOLD', 0.45 );
define( 'ILS_CANDIDATE_COUNT', 5 );
define( 'ILS_MAX_SUGGESTIONS', 3 );
define( 'ILS_MIN_WORDS', 120 );
define( 'ILS_MAX_EMBED_CHARS', 1024 );
define( 'ILS_BATCH_SIZE', 7 );

// --- WP function stubs ---
if ( ! function_exists( '__' ) ) {
	function __( $text, $domain = 'default' ) {
		return $text;
	}
}
if ( ! function_exists( 'wp_parse_url' ) ) {
	function wp_parse_url( $url, $component = -1 ) {
		return parse_url( $url, $component );
	}
}
if ( ! function_exists( 'home_url' ) ) {
	function home_url( $path = '' ) {
		return 'https://example.com' . $path;
	}
}
if ( ! function_exists( 'wp_strip_all_tags' ) ) {
	function wp_strip_all_tags( $string, $remove_breaks = false ) {
		$string = preg_replace( '@<(script|style)[^>]*?>.*?</\\1>@si', '', (string) $string );
		$string = strip_tags( $string );
		if ( $remove_breaks ) {
			$string = preg_replace( '/[\r\n\t ]+/', ' ', $string );
		}
		return trim( $string );
	}
}
if ( ! function_exists( 'esc_url' ) ) {
	function esc_url( $url ) {
		return $url;
	}
}

// Load only the classes whose pure methods we test (no DB/HTTP needed to define them).
require_once dirname( __DIR__ ) . '/includes/class-ils-suggester.php';
require_once dirname( __DIR__ ) . '/includes/class-ils-embeddings.php';
