=== Internal Link Suggester – AI Internal Linking for SEO ===
Contributors: mahdikhalili
Tags: internal linking, internal links, seo, ai, link building
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI internal linking that adds value, not spam. Find semantically relevant internal links with OpenAI embeddings, review, and apply in one click.

== Description ==

**Internal Link Suggester** finds genuinely relevant internal links for your posts using AI — not dumb keyword matching. It reads your content with OpenAI embeddings, measures semantic similarity between every post, then asks GPT-4o to propose links that *add value for the reader* while following strict anti-spam SEO rules.

Every suggestion is shown in a review table. You approve what you want and apply it to the post with one click. Nothing is auto-published behind your back.

= Why it's different =

Most auto-linking plugins stuff exact-match anchors and create spammy, redundant links that hurt UX and SEO. This plugin is built around quality:

* **Semantic, not keyword.** Uses OpenAI `text-embedding-3-small` + cosine similarity to find truly related posts.
* **AI value-check.** GPT-4o only suggests a link if it adds new, supplementary information for the reader.
* **Anti-duplicate.** Skips posts you already link to, and never re-suggests an anchor/URL pair that's already linked.
* **No generic anchors.** Forbids "click here", "read more", "learn more" — anchors must be specific phrases pulled from your content.
* **Human in the loop.** Review and apply each suggestion yourself. One-click apply, no surprises.
* **Multilingual-friendly.** Works on non-English content (embeddings are language-aware). Fully translatable.

= How it works =

1. **Sync Embeddings** — the plugin reads your published posts, cleans the content, and stores an AI embedding for each one in a custom database table.
2. **Find Link Suggestions** — for posts not yet processed, it finds the most similar candidate posts, then asks the AI for high-value internal links.
3. **Review & Apply** — pending suggestions appear in an admin table with anchor text, target, reason, and the exact sentence. Click **Apply** to insert the link, or **Dismiss** to discard it.

= Bring your own API key =

You use your own OpenAI API key, so you stay in full control of usage and cost. The plugin only calls OpenAI when you click Sync or Find.

= Privacy =

When you run a sync or search, post content is sent to the OpenAI API to generate embeddings and link suggestions. No data is sent anywhere else. See your OpenAI account for their data handling. Review OpenAI's privacy policy before processing content you consider sensitive.

== Installation ==

1. Upload the `internal-link-suggester` folder to `/wp-content/plugins/`, or install the ZIP via **Plugins → Add New → Upload Plugin**.
2. Activate the plugin. Custom tables are created automatically.
3. Go to **Link Suggester → Settings** and paste your OpenAI API key.
4. Open **Link Suggester**, click **Sync Embeddings**, then **Find Link Suggestions**.
5. Review the suggestions and click **Apply** on the ones you want.

== Frequently Asked Questions ==

= Do I need an OpenAI API key? =
Yes. The plugin uses your own key for embeddings and suggestions, so you control usage and billing. Add it under Link Suggester → Settings.

= Will it change my posts automatically? =
No. Suggestions are stored for review. A link is only inserted into a post when you click **Apply** on that specific suggestion.

= How much does the OpenAI usage cost? =
Embeddings (`text-embedding-3-small`) are very cheap — a fraction of a cent per post. Suggestions use GPT-4o and cost a little more per processed post. You pay OpenAI directly.

= Does it work with languages other than English? =
Yes. Embeddings handle many languages, so it finds related posts in non-English content. The interface is fully translatable.

= Does it support custom post types or WooCommerce products? =
Version 1.0 processes standard posts. Custom post type and WooCommerce support are planned.

= Can I undo an applied link? =
Applied links edit the post content directly. You can remove the link in the post editor. A built-in undo is planned.

= How many posts are processed at once? =
Sync handles 25 posts per click; Find Link Suggestions processes 7 unprocessed posts per click. Run repeatedly to work through a large site.

= Where is my data stored? =
Embeddings and suggestions are stored in two custom tables in your own WordPress database. Nothing is stored on third-party servers.

== Screenshots ==

1. Suggestions review table with anchor text, target, reason, and one-click Apply.
2. Settings page — OpenAI API key and model selection.
3. Action bar — Sync Embeddings and Find Link Suggestions.

== Changelog ==

= 1.0.0 =
* Initial release.
* OpenAI embeddings (`text-embedding-3-small`) with cosine-similarity matching.
* GPT-4o link suggestions with anti-spam, anti-duplicate SEO rules.
* Admin review table with one-click apply and dismiss.
* Custom database tables for embeddings and suggestions.
* Full internationalization (i18n) with included POT file.

== Upgrade Notice ==

= 1.0.0 =
First public release.
