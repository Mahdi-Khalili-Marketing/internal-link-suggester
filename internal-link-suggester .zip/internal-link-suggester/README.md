# Internal Link Suggester (WordPress plugin)

PHP port of the n8n "internal link suggester" flow. No n8n, no Google Sheets — runs inside WordPress, stores data in custom MySQL tables.

## What it does

1. **Sync Embeddings** — reads published posts (≥120 words), cleans HTML, sends first 1024 chars to OpenAI `text-embedding-3-small`, stores the vector in `wp_ils_embeddings`. Skips posts already embedded and unmodified. Processes 25 posts per click.
2. **Find Link Suggestions** — for up to 7 not-yet-processed posts: extracts existing links/anchors from the post, finds candidate posts by cosine similarity > 0.45, takes top 5, sends them to `gpt-4o` with the SEO/anti-duplicate prompt, stores returned suggestions in `wp_ils_suggestions`.
3. **Review + Apply** — admin table lists pending suggestions. **Apply** inserts the `<a>` tag into the post content at the AI-provided sentence (first un-linked occurrence of the anchor). **Dismiss** discards it.

## Mapping to the n8n flow

| n8n node | Plugin equivalent |
|---|---|
| Fetch All Posts / Clean / Store | `ILS_Embeddings::sync()` (uses `WP_Query`, posts are local) |
| Generate Embeddings | `ILS_OpenAI::embed()` |
| Store Embeddings (Sheet) | `wp_ils_embeddings` table |
| Get IDs / Processed / Prepare (nodes 1-4) | `ILS_Suggester::run_batch()` |
| Process & Find Similar (node 5) | `ILS_Suggester::run_for_post()` |
| Construct AI Prompt (node 7) | `ILS_Suggester::build_prompt()` |
| Call OpenAI (node 8) | `ILS_OpenAI::chat_json()` |
| Process AI Response (node 9) | `ILS_Suggester::process_response()` |
| Log Suggestions (Sheet, node 10) | `wp_ils_suggestions` table |

## Tuning (constants in `internal-link-suggester.php`, same as flow)

`ILS_SIMILARITY_THRESHOLD=0.45`, `ILS_CANDIDATE_COUNT=5`, `ILS_MAX_SUGGESTIONS=3`, `ILS_MIN_WORDS=120`, `ILS_MAX_EMBED_CHARS=1024`, `ILS_BATCH_SIZE=7`.

## Install

1. Zip the `internal-link-suggester` folder (or upload it to `wp-content/plugins/`).
2. Activate in **Plugins**. Tables are created on activation.
3. **Link Suggester → Settings** → paste OpenAI API key.
4. **Link Suggester** → Sync Embeddings, then Find Link Suggestions.

## Translation (i18n)

All admin strings are wrapped in `__()` / `esc_html_e()` with text domain `ils`. Template: `languages/ils.pot` (33 strings).

To translate (e.g. Persian):
1. Open `languages/ils.pot` in **Poedit** → "Create new translation" → pick language.
2. Save as `languages/ils-fa_IR.po` + `.mo` (Poedit writes both).
3. WordPress loads it automatically per site locale (`load_plugin_textdomain` on `init`).

Regenerate the `.pot` after adding strings (needs WP-CLI):
```
wp i18n make-pot . languages/ils.pot --domain=ils
```

**Not translated on purpose:** the AI prompt text in `ILS_Suggester::build_prompt()` — it is sent to OpenAI and must stay English for model quality.

## Notes / differences from n8n

- Posts are read locally, not via `/wp-json/wp/v2/posts`. The flow's "fetch live HTML" step is unnecessary — `post_content` is the source of truth.
- Embeddings are computed inside WP; vectors stored as JSON in `LONGTEXT`. For thousands of posts, similarity is computed in PHP each run (fine for low-thousands; move to a vector store if it grows).
- Apply edits `post_content` and runs `wp_update_post`. A human approves each link — no auto-insertion.
