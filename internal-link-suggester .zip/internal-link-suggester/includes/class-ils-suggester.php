<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Part 2 of the flow: find similar posts, ask the AI, log suggestions.
 * PHP port of n8n nodes 5 (Process & Find Similar), 7 (Construct AI Prompt), 9 (Process AI Response).
 */
class ILS_Suggester {

	/* ---------- URL / link helpers (ports of the JS helpers) ---------- */

	public static function get_base_url( $url ) {
		$parts = wp_parse_url( $url );
		if ( ! $parts || empty( $parts['host'] ) ) {
			return home_url();
		}
		$scheme = isset( $parts['scheme'] ) ? $parts['scheme'] : 'https';
		$host   = preg_replace( '/^www\./', '', $parts['host'] );
		return $scheme . '://' . $host;
	}

	/** Lower-cased, www-stripped, trailing-slash-stripped, query/fragment-dropped URL. */
	public static function normalize_url( $url ) {
		if ( ! is_string( $url ) || '' === trim( $url ) || 0 === strpos( $url, '#' ) ) {
			return '';
		}
		$parts = wp_parse_url( $url );
		if ( ! $parts || empty( $parts['host'] ) ) {
			return '';
		}
		$scheme = isset( $parts['scheme'] ) ? $parts['scheme'] : 'https';
		$host   = preg_replace( '/^www\./', '', $parts['host'] );
		$path   = isset( $parts['path'] ) ? rtrim( $parts['path'], '/' ) : '';
		return strtolower( $scheme . '://' . $host . $path );
	}

	/** Extract normalized hrefs from HTML. Port of extractLinks(). */
	public static function extract_links( $html, $base_url ) {
		if ( ! is_string( $html ) ) {
			return array();
		}
		$out = array();
		if ( preg_match_all( '/<a\s+(?:[^>]*?\s+)?href=([\"\'])(.*?)\1/i', $html, $m ) ) {
			foreach ( $m[2] as $href ) {
				if ( '' === $href
					|| 0 === strpos( $href, '#' )
					|| 0 === strpos( $href, 'mailto:' )
					|| 0 === strpos( $href, 'tel:' ) ) {
					continue;
				}
				if ( 0 === strpos( $href, 'http' ) ) {
					$full = $href;
				} elseif ( 0 === strpos( $href, '/' ) ) {
					$full = $base_url . $href;
				} else {
					continue;
				}
				$norm = self::normalize_url( $full );
				if ( $norm ) {
					$out[ $norm ] = true;
				}
			}
		}
		return array_keys( $out );
	}

	/** Extract {url, anchor} pairs from HTML. Port of extractAnchorsWithUrls(). */
	public static function extract_anchors( $html, $base_url ) {
		if ( ! is_string( $html ) ) {
			return array();
		}
		$out = array();
		if ( preg_match_all( '/<a\s+[^>]*href=[\"\']([^\"\']+)[\"\'][^>]*>([\s\S]*?)<\/a>/i', $html, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $match ) {
				$href = $match[1];
				$text = trim( preg_replace( '/<[^>]+>/', '', $match[2] ) );
				if ( '' === $href || '' === $text ) {
					continue;
				}
				$full = ( 0 === strpos( $href, 'http' ) ) ? $href : $base_url . $href;
				$norm = self::normalize_url( $full );
				if ( $norm && '' !== $text ) {
					$out[] = array(
						'url'    => $norm,
						'anchor' => $text,
					);
				}
			}
		}
		return $out;
	}

	/** Cosine similarity between two JSON-encoded vectors. Port of calculateSimilarity(). */
	public static function cosine( $vec_a_json, $vec_b_json ) {
		$a = json_decode( (string) $vec_a_json, true );
		$b = json_decode( (string) $vec_b_json, true );
		if ( ! is_array( $a ) || ! is_array( $b ) || count( $a ) !== count( $b ) ) {
			return 0.0;
		}
		$dot = 0.0;
		$ma  = 0.0;
		$mb  = 0.0;
		$n   = count( $a );
		for ( $i = 0; $i < $n; $i++ ) {
			$x    = isset( $a[ $i ] ) ? (float) $a[ $i ] : 0.0;
			$y    = isset( $b[ $i ] ) ? (float) $b[ $i ] : 0.0;
			$dot += $x * $y;
			$ma  += $x * $x;
			$mb  += $y * $y;
		}
		$ma = sqrt( $ma );
		$mb = sqrt( $mb );
		if ( 0.0 === $ma || 0.0 === $mb ) {
			return 0.0;
		}
		return $dot / ( $ma * $mb );
	}

	/* ---------- Orchestration ---------- */

	/**
	 * Run suggestions for up to ILS_BATCH_SIZE unprocessed posts.
	 * "Unprocessed" = has an embedding but no suggestions logged yet (nodes 1-4).
	 *
	 * @return array ['posts'=>int,'suggestions'=>int,'errors'=>array]
	 */
	public static function run_batch() {
		$summary = array(
			'posts'       => 0,
			'suggestions' => 0,
			'errors'      => array(),
		);

		$all_ids       = ILS_DB::get_embedded_post_ids();
		$processed_ids = ILS_DB::get_processed_post_ids();
		$unprocessed   = array_values( array_diff( $all_ids, $processed_ids ) );
		$unprocessed   = array_slice( $unprocessed, 0, ILS_BATCH_SIZE );

		$all_embeddings = ILS_DB::get_all_embeddings();

		foreach ( $unprocessed as $post_id ) {
			$res = self::run_for_post( $post_id, $all_embeddings );
			if ( is_wp_error( $res ) ) {
				$summary['errors'][] = '#' . $post_id . ': ' . $res->get_error_message();
				continue;
			}
			++$summary['posts'];
			$summary['suggestions'] += $res;
		}

		return $summary;
	}

	/** Force-run for one post even if it was processed before (used by "re-run"). */
	public static function run_for_post( $post_id, $all_embeddings = null ) {
		if ( null === $all_embeddings ) {
			$all_embeddings = ILS_DB::get_all_embeddings();
		}

		$current = ILS_DB::get_embedding( $post_id );
		if ( ! $current || empty( $current['embedding'] ) || empty( $current['post_url'] ) ) {
			return new WP_Error( 'ils_no_embedding', __( 'Post has no embedding yet.', 'ils' ) );
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error( 'ils_no_post', __( 'Post not found.', 'ils' ) );
		}

		$base_url = self::get_base_url( $current['post_url'] );
		$html     = $post->post_content;

		$existing_links     = self::extract_links( $html, $base_url );
		$existing_links_set = array_flip( $existing_links );
		$existing_anchors   = self::extract_anchors( $html, $base_url );

		// Candidate filter: has embedding+url, not self, not already linked. (node 5)
		$candidates = array();
		foreach ( $all_embeddings as $p ) {
			if ( empty( $p['embedding'] ) || empty( $p['post_url'] ) ) {
				continue;
			}
			if ( (string) $p['post_id'] === (string) $post_id ) {
				continue;
			}
			if ( isset( $existing_links_set[ self::normalize_url( $p['post_url'] ) ] ) ) {
				continue;
			}
			$sim = self::cosine( $current['embedding'], $p['embedding'] );
			if ( $sim > ILS_SIMILARITY_THRESHOLD ) {
				$p['similarity'] = $sim;
				$candidates[]    = $p;
			}
		}

		usort(
			$candidates,
			function ( $a, $b ) {
				return $b['similarity'] <=> $a['similarity'];
			}
		);
		$candidates = array_slice( $candidates, 0, ILS_CANDIDATE_COUNT );

		if ( empty( $candidates ) ) {
			return 0; // node 6: IF Links Found = false.
		}

		$candidates_str = array();
		foreach ( $candidates as $c ) {
			$candidates_str[] = 'Title: ' . $c['post_title'] . "\nURL: " . $c['post_url'];
		}
		$candidates_str = implode( "\n---\n", $candidates_str );

		$messages = self::build_prompt(
			$current['plain_text'],
			$candidates_str,
			$current['post_title'],
			$existing_anchors
		);

		$content = ILS_OpenAI::chat_json( $messages );
		if ( is_wp_error( $content ) ) {
			return $content;
		}

		return self::process_response( $content, $current );
	}

	/** Port of node 7. Returns OpenAI chat messages array. */
	private static function build_prompt( $main_content, $linkable_posts, $current_title, $used_anchors ) {
		$main_content   = $main_content ? $main_content : 'No content available.';
		$linkable_posts = $linkable_posts ? $linkable_posts : 'No candidates available.';
		$max            = ILS_MAX_SUGGESTIONS;

		if ( empty( $used_anchors ) ) {
			$used_anchors_str = '[]';
		} else {
			$lines = array();
			foreach ( $used_anchors as $x ) {
				$lines[] = 'Anchor: "' . $x['anchor'] . '"   |   URL: ' . $x['url'];
			}
			$used_anchors_str = implode( "\n", $lines );
		}

		$prompt = <<<PROMPT
You are a senior SEO strategist. Your priority is user experience and adding genuine value.
Your task is to analyze the 'Main Post Content' and suggest up to {$max} highly relevant internal links from the 'Link Candidates'.

**CRITICAL RULES YOU MUST FOLLOW:**

1.  **ADD VALUE, DON'T REPEAT:** The suggested link MUST offer new, supplementary information. It should answer a logical next question or expand on a related sub-topic.
2.  **AVOID REDUNDANT LINKS:**
    *   **NO GENERAL FROM SPECIFIC:** Do NOT link from a specific article (e.g., "Ungating in LEGO") to a more general one (e.g., "Ungating in Toys" or "What is Ungating?"). This is a bad user experience.
    *   Do not suggest a link if its topic is already the main subject of the current article.

3.  **STRICT ANCHOR TEXT RULES:**
    *   The anchor text MUST be a specific, descriptive phrase (3-7 words) that accurately reflects the target page's content.
    *   The anchor text MUST be selected DIRECTLY from the 'Main Post Content'. DO NOT invent or rephrase it.
    *   **FORBIDDEN ANCHORS:** Absolutely NO generic phrases like "gain more profits", "click here", "read more", "learn more", "this article", etc.

4.  **NO DUPLICATE ANCHOR LINKS:**
    *   If an anchor text in 'Main Post Content' is already hyperlinked to a certain URL (as shown in the list below), you are absolutely FORBIDDEN from suggesting the same anchor text to the same URL again—even if it appears elsewhere in the content without a link.
    *   Here is the list of currently linked anchor texts and their URLs. DO NOT suggest these pairs again:
{$used_anchors_str}

5.  **OUTPUT FORMATTING:**
    *   Return ONLY a valid JSON object with a single key "suggestions", which is an array of objects.
    *   Each object MUST have these 4 keys: "anchorText", "link", "reason", and "contextualSentence".
    *   "contextualSentence" MUST be the full sentence from the 'Main Post Content' where your chosen "anchorText" is located.
    *   "reason" must briefly explain WHY the link adds value to the reader, following the rules above.

---
**Current Article Title:**
{$current_title}

---
**Main Post Content (Source):**
{$main_content}

---
**Link Candidates (Destinations):**
{$linkable_posts}
---
PROMPT;

		return array(
			array(
				'role'    => 'system',
				'content' => 'You are a world-class SEO strategist that outputs only valid JSON, strictly following all user-defined rules without exception.',
			),
			array(
				'role'    => 'user',
				'content' => $prompt,
			),
		);
	}

	/** Port of node 9. Parses AI JSON, stores valid suggestions, returns count saved. */
	private static function process_response( $content, $current ) {
		$content = trim( $content );
		$parsed  = json_decode( $content, true );
		if ( ! is_array( $parsed ) || empty( $parsed['suggestions'] ) || ! is_array( $parsed['suggestions'] ) ) {
			return 0;
		}

		$saved = 0;
		foreach ( $parsed['suggestions'] as $s ) {
			if ( empty( $s['anchorText'] ) || empty( $s['link'] ) || empty( $s['contextualSentence'] ) ) {
				continue;
			}
			ILS_DB::insert_suggestion(
				array(
					'source_post_id'      => (int) $current['post_id'],
					'source_url'          => $current['post_url'],
					'source_title'        => $current['post_title'],
					'anchor_text'         => $s['anchorText'],
					'link'                => $s['link'],
					'reason'              => isset( $s['reason'] ) ? $s['reason'] : 'No reason provided',
					'contextual_sentence' => $s['contextualSentence'],
					'status'              => 'pending',
				)
			);
			++$saved;
		}
		return $saved;
	}
}
