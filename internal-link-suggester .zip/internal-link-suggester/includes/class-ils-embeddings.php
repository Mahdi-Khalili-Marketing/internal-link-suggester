<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Part 1 of the flow: data population.
 * Original flow fetched posts via WP REST, cleaned HTML, stored them, then embedded.
 * Here posts are already local, so we read them with WP_Query and embed missing/stale ones.
 */
class ILS_Embeddings {

	/** Strip tags + collapse whitespace. Mirrors cleanHTML() in the flow. */
	public static function clean_html( $html ) {
		$text = wp_strip_all_tags( (string) $html );
		$text = preg_replace( '/\s+/', ' ', $text );
		return trim( $text );
	}

	/** Word count on cleaned text. */
	private static function word_count( $text ) {
		return count( preg_split( '/\s+/', trim( $text ), -1, PREG_SPLIT_NO_EMPTY ) );
	}

	/**
	 * Embed all published posts that have no embedding yet (or were modified since).
	 *
	 * @param int $limit Max posts to process this run (keeps requests bounded).
	 * @return array     ['embedded'=>int,'skipped'=>int,'errors'=>array]
	 */
	public static function sync( $limit = 25 ) {
		$result = array(
			'embedded' => 0,
			'skipped'  => 0,
			'errors'   => array(),
		);

		$query = new WP_Query(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$post_ids = $query->posts;

		$processed = 0;
		foreach ( $post_ids as $post_id ) {
			if ( $processed >= $limit ) {
				break;
			}

			$post = get_post( $post_id );
			if ( ! $post ) {
				continue;
			}

			$plain = self::clean_html( $post->post_content );
			if ( self::word_count( $plain ) < ILS_MIN_WORDS ) {
				++$result['skipped'];
				continue;
			}

			// Skip if already embedded and not modified since.
			$existing = ILS_DB::get_embedding( $post_id );
			if ( $existing && strtotime( $existing['updated_at'] ) >= strtotime( $post->post_modified ) ) {
				++$result['skipped'];
				continue;
			}

			$input     = mb_substr( $plain, 0, ILS_MAX_EMBED_CHARS );
			$embedding = ILS_OpenAI::embed( $input );

			if ( is_wp_error( $embedding ) ) {
				$result['errors'][] = '#' . $post_id . ': ' . $embedding->get_error_message();
				++$processed;
				continue;
			}

			ILS_DB::upsert_embedding(
				$post_id,
				get_the_title( $post_id ),
				get_permalink( $post_id ),
				$input,
				wp_json_encode( $embedding )
			);
			++$result['embedded'];
			++$processed;
		}

		return $result;
	}
}
