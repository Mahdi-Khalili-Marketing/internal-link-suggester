<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin UI: settings page, action buttons, suggestion review table, 1-click apply.
 */
class ILS_Admin {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );

		add_action( 'wp_ajax_ils_sync_embeddings', array( $this, 'ajax_sync_embeddings' ) );
		add_action( 'wp_ajax_ils_find_suggestions', array( $this, 'ajax_find_suggestions' ) );
		add_action( 'wp_ajax_ils_apply_suggestion', array( $this, 'ajax_apply_suggestion' ) );
		add_action( 'wp_ajax_ils_dismiss_suggestion', array( $this, 'ajax_dismiss_suggestion' ) );
	}

	/* ---------- Menu / settings ---------- */

	public function menu() {
		add_menu_page(
			__( 'Internal Link Suggester', 'ils' ),
			__( 'Link Suggester', 'ils' ),
			'manage_options',
			'ils-dashboard',
			array( $this, 'render_dashboard' ),
			'dashicons-admin-links',
			58
		);
		add_submenu_page(
			'ils-dashboard',
			__( 'Settings', 'ils' ),
			__( 'Settings', 'ils' ),
			'manage_options',
			'ils-settings',
			array( $this, 'render_settings' )
		);
	}

	public function register_settings() {
		register_setting(
			'ils_settings_group',
			'ils_settings',
			array( $this, 'sanitize_settings' )
		);
	}

	public function sanitize_settings( $input ) {
		return array(
			'openai_api_key' => isset( $input['openai_api_key'] ) ? trim( $input['openai_api_key'] ) : '',
			'embed_model'    => isset( $input['embed_model'] ) ? sanitize_text_field( $input['embed_model'] ) : 'text-embedding-3-small',
			'chat_model'     => isset( $input['chat_model'] ) ? sanitize_text_field( $input['chat_model'] ) : 'gpt-4o',
		);
	}

	public function assets( $hook ) {
		if ( false === strpos( $hook, 'ils-' ) ) {
			return;
		}
		wp_enqueue_style( 'ils-admin', ILS_PLUGIN_URL . 'assets/admin.css', array(), ILS_VERSION );
		wp_enqueue_script( 'ils-admin', ILS_PLUGIN_URL . 'assets/admin.js', array( 'jquery' ), ILS_VERSION, true );
		wp_localize_script(
			'ils-admin',
			'ILS',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'ils_nonce' ),
			)
		);
	}

	/* ---------- Pages ---------- */

	public function render_settings() {
		$opts = get_option( 'ils_settings', array() );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Link Suggester — Settings', 'ils' ); ?></h1>
			<form method="post" action="options.php">
				<?php settings_fields( 'ils_settings_group' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="ils_key"><?php esc_html_e( 'OpenAI API Key', 'ils' ); ?></label></th>
						<td><input type="password" id="ils_key" name="ils_settings[openai_api_key]" class="regular-text"
							value="<?php echo esc_attr( isset( $opts['openai_api_key'] ) ? $opts['openai_api_key'] : '' ); ?>" autocomplete="off" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="ils_embed"><?php esc_html_e( 'Embedding Model', 'ils' ); ?></label></th>
						<td><input type="text" id="ils_embed" name="ils_settings[embed_model]" class="regular-text"
							value="<?php echo esc_attr( ! empty( $opts['embed_model'] ) ? $opts['embed_model'] : 'text-embedding-3-small' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="ils_chat"><?php esc_html_e( 'Chat Model', 'ils' ); ?></label></th>
						<td><input type="text" id="ils_chat" name="ils_settings[chat_model]" class="regular-text"
							value="<?php echo esc_attr( ! empty( $opts['chat_model'] ) ? $opts['chat_model'] : 'gpt-4o' ); ?>" /></td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	public function render_dashboard() {
		$pending = ILS_DB::get_suggestions( 'pending' );
		?>
		<div class="wrap ils-wrap">
			<h1><?php esc_html_e( 'Internal Link Suggester', 'ils' ); ?></h1>

			<div class="ils-actions">
				<button class="button button-secondary" id="ils-sync"><?php esc_html_e( '1. Sync Embeddings', 'ils' ); ?></button>
				<button class="button button-primary" id="ils-find"><?php esc_html_e( '2. Find Link Suggestions', 'ils' ); ?></button>
				<span class="ils-status" id="ils-status"></span>
			</div>

			<p class="description">
				<?php
				printf(
					/* translators: %d: number of posts processed per click. */
					esc_html__( 'Sync embeddings first (processes posts in batches of 25 per click). Then Find Suggestions runs the AI over %d unprocessed posts per click.', 'ils' ),
					(int) ILS_BATCH_SIZE
				);
				?>
			</p>

			<h2>
				<?php
				printf(
					/* translators: %d: number of pending suggestions. */
					esc_html__( 'Pending Suggestions (%d)', 'ils' ),
					count( $pending )
				);
				?>
			</h2>
			<table class="widefat striped ils-table" id="ils-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Source Post', 'ils' ); ?></th>
						<th><?php esc_html_e( 'Anchor Text', 'ils' ); ?></th>
						<th><?php esc_html_e( 'Links To', 'ils' ); ?></th>
						<th><?php esc_html_e( 'Reason', 'ils' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'ils' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $pending ) ) : ?>
						<tr><td colspan="5"><?php esc_html_e( 'No pending suggestions. Run the actions above.', 'ils' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $pending as $s ) : ?>
							<tr data-id="<?php echo (int) $s['id']; ?>">
								<td>
									<a href="<?php echo esc_url( get_edit_post_link( $s['source_post_id'] ) ); ?>" target="_blank">
										<?php echo esc_html( $s['source_title'] ); ?>
									</a>
								</td>
								<td><code><?php echo esc_html( $s['anchor_text'] ); ?></code></td>
								<td><a href="<?php echo esc_url( $s['link'] ); ?>" target="_blank"><?php echo esc_html( $s['link'] ); ?></a></td>
								<td>
									<?php echo esc_html( $s['reason'] ); ?>
									<div class="ils-context"><em><?php echo esc_html( $s['contextual_sentence'] ); ?></em></div>
								</td>
								<td class="ils-row-actions">
									<button class="button button-primary ils-apply"><?php esc_html_e( 'Apply', 'ils' ); ?></button>
									<button class="button ils-dismiss"><?php esc_html_e( 'Dismiss', 'ils' ); ?></button>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* ---------- AJAX ---------- */

	private function check() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'ils_nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'ils' ) ), 403 );
		}
	}

	public function ajax_sync_embeddings() {
		$this->check();
		$res    = ILS_Embeddings::sync( 25 );
		$errors = $res['errors']
			? ' ' . sprintf(
				/* translators: %s: pipe-separated error list. */
				__( 'Errors: %s', 'ils' ),
				implode( ' | ', $res['errors'] )
			)
			: '';
		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: 1: count embedded, 2: count skipped, 3: appended error text. */
					__( 'Embedded %1$d, skipped %2$d.%3$s', 'ils' ),
					$res['embedded'],
					$res['skipped'],
					$errors
				),
			)
		);
	}

	public function ajax_find_suggestions() {
		$this->check();
		$res    = ILS_Suggester::run_batch();
		$errors = $res['errors']
			? ' ' . sprintf(
				/* translators: %s: pipe-separated error list. */
				__( 'Errors: %s', 'ils' ),
				implode( ' | ', $res['errors'] )
			)
			: '';
		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: 1: count posts processed, 2: count suggestions found, 3: appended error text. */
					__( 'Processed %1$d posts, found %2$d suggestions.%3$s', 'ils' ),
					$res['posts'],
					$res['suggestions'],
					$errors
				),
				'reload'  => $res['suggestions'] > 0,
			)
		);
	}

	public function ajax_apply_suggestion() {
		$this->check();
		$id  = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$sug = ILS_DB::get_suggestion( $id );
		if ( ! $sug ) {
			wp_send_json_error( array( 'message' => __( 'Suggestion not found.', 'ils' ) ) );
		}

		$applied = $this->insert_link_into_post(
			(int) $sug['source_post_id'],
			$sug['anchor_text'],
			$sug['link'],
			$sug['contextual_sentence']
		);

		if ( is_wp_error( $applied ) ) {
			wp_send_json_error( array( 'message' => $applied->get_error_message() ) );
		}

		ILS_DB::set_suggestion_status( $id, 'applied' );
		wp_send_json_success( array( 'message' => __( 'Link applied.', 'ils' ) ) );
	}

	public function ajax_dismiss_suggestion() {
		$this->check();
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		ILS_DB::set_suggestion_status( $id, 'dismissed' );
		wp_send_json_success( array( 'message' => __( 'Dismissed.', 'ils' ) ) );
	}

	/* ---------- Apply logic ---------- */

	/**
	 * Wrap the first un-linked occurrence of $anchor with an <a> tag, preferring the
	 * location inside $context_sentence. Updates the post content.
	 *
	 * @return true|WP_Error
	 */
	private function insert_link_into_post( $post_id, $anchor, $link, $context_sentence ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return new WP_Error( 'ils_no_post', __( 'Post not found.', 'ils' ) );
		}

		$content    = $post->post_content;
		$anchor     = trim( $anchor );
		$link_tag   = '<a href="' . esc_url( $link ) . '">' . $anchor . '</a>';

		if ( '' === $anchor ) {
			return new WP_Error( 'ils_bad_anchor', __( 'Empty anchor text.', 'ils' ) );
		}

		// Already linked to this exact URL with this anchor? Treat as done.
		if ( false !== strpos( $content, $link_tag ) ) {
			return true;
		}

		$replaced = false;

		// Prefer replacing inside the AI-provided context sentence.
		if ( $context_sentence && false !== strpos( $content, $context_sentence ) ) {
			$new_sentence = $this->replace_first_unlinked( $context_sentence, $anchor, $link_tag, $replaced );
			if ( $replaced ) {
				$content = $this->str_replace_first( $context_sentence, $new_sentence, $content );
			}
		}

		// Fallback: first un-linked occurrence anywhere in the content.
		if ( ! $replaced ) {
			$content = $this->replace_first_unlinked( $content, $anchor, $link_tag, $replaced );
		}

		if ( ! $replaced ) {
			return new WP_Error( 'ils_anchor_not_found', __( 'Anchor text not found in post (it may already be linked or edited).', 'ils' ) );
		}

		$update = wp_update_post(
			array(
				'ID'           => $post_id,
				'post_content' => $content,
			),
			true
		);
		if ( is_wp_error( $update ) ) {
			return $update;
		}
		return true;
	}

	/** Replace the first occurrence of $anchor not already inside an <a>…</a>. */
	private function replace_first_unlinked( $haystack, $anchor, $replacement, &$replaced ) {
		$replaced = false;
		$offset   = 0;
		$len      = strlen( $anchor );

		// Walk occurrences, skip any that already sit inside an <a>…</a>.
		while ( ( $pos = strpos( $haystack, $anchor, $offset ) ) !== false ) {
			if ( ! $this->is_inside_anchor( $haystack, $pos ) ) {
				$haystack = substr( $haystack, 0, $pos ) . $replacement . substr( $haystack, $pos + $len );
				$replaced = true;
				break;
			}
			$offset = $pos + $len;
		}
		return $haystack;
	}

	/** True if byte offset $pos sits between an <a ...> and its closing </a>. */
	private function is_inside_anchor( $html, $pos ) {
		$open  = strripos( substr( $html, 0, $pos ), '<a ' );
		if ( false === $open ) {
			return false;
		}
		$close = strripos( substr( $html, 0, $pos ), '</a>' );
		return ( false === $close || $close < $open );
	}

	private function str_replace_first( $search, $replace, $subject ) {
		$pos = strpos( $subject, $search );
		if ( false === $pos ) {
			return $subject;
		}
		return substr( $subject, 0, $pos ) . $replace . substr( $subject, $pos + strlen( $search ) );
	}
}
