<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Thin OpenAI HTTP client. Replaces the n8n "Generate Embeddings" and "Call OpenAI" HTTP nodes.
 */
class ILS_OpenAI {

	private static function api_key() {
		$opts = get_option( 'ils_settings', array() );
		return isset( $opts['openai_api_key'] ) ? trim( $opts['openai_api_key'] ) : '';
	}

	private static function embed_model() {
		$opts = get_option( 'ils_settings', array() );
		return ! empty( $opts['embed_model'] ) ? $opts['embed_model'] : 'text-embedding-3-small';
	}

	private static function chat_model() {
		$opts = get_option( 'ils_settings', array() );
		return ! empty( $opts['chat_model'] ) ? $opts['chat_model'] : 'gpt-4o';
	}

	/**
	 * @return array|WP_Error  Embedding vector (array of floats) or error.
	 */
	public static function embed( $text ) {
		$key = self::api_key();
		if ( '' === $key ) {
			return new WP_Error( 'ils_no_key', __( 'OpenAI API key is not set.', 'ils' ) );
		}

		$res = wp_remote_post(
			'https://api.openai.com/v1/embeddings',
			array(
				'timeout' => 60,
				'headers' => array(
					'Authorization' => 'Bearer ' . $key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'input' => $text,
						'model' => self::embed_model(),
					)
				),
			)
		);

		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( 200 !== $code || empty( $body['data'][0]['embedding'] ) ) {
			$msg = isset( $body['error']['message'] )
				? $body['error']['message']
				: sprintf(
					/* translators: %d: HTTP status code. */
					__( 'Embedding request failed (HTTP %d).', 'ils' ),
					$code
				);
			return new WP_Error( 'ils_embed_failed', $msg );
		}
		return $body['data'][0]['embedding'];
	}

	/**
	 * Chat completion forced to JSON object output.
	 *
	 * @return string|WP_Error  Raw assistant message content (JSON string) or error.
	 */
	public static function chat_json( $messages ) {
		$key = self::api_key();
		if ( '' === $key ) {
			return new WP_Error( 'ils_no_key', __( 'OpenAI API key is not set.', 'ils' ) );
		}

		$res = wp_remote_post(
			'https://api.openai.com/v1/chat/completions',
			array(
				'timeout' => 120,
				'headers' => array(
					'Authorization' => 'Bearer ' . $key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'model'           => self::chat_model(),
						'messages'        => $messages,
						'response_format' => array( 'type' => 'json_object' ),
					)
				),
			)
		);

		if ( is_wp_error( $res ) ) {
			return $res;
		}
		$code = wp_remote_retrieve_response_code( $res );
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( 200 !== $code || ! isset( $body['choices'][0]['message']['content'] ) ) {
			$msg = isset( $body['error']['message'] )
				? $body['error']['message']
				: sprintf(
					/* translators: %d: HTTP status code. */
					__( 'Chat request failed (HTTP %d).', 'ils' ),
					$code
				);
			return new WP_Error( 'ils_chat_failed', $msg );
		}
		return $body['choices'][0]['message']['content'];
	}
}
