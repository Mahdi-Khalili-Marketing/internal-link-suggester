<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Storage layer. Replaces the Google Sheets nodes with two custom MySQL tables.
 *   {prefix}ils_embeddings  — one row per post (the "Embedding Data" sheet)
 *   {prefix}ils_suggestions — one row per suggested link (the "Log Suggestions" sheet)
 */
class ILS_DB {

	public static function embeddings_table() {
		global $wpdb;
		return $wpdb->prefix . 'ils_embeddings';
	}

	public static function suggestions_table() {
		global $wpdb;
		return $wpdb->prefix . 'ils_suggestions';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$emb             = self::embeddings_table();
		$sug             = self::suggestions_table();

		$sql_emb = "CREATE TABLE {$emb} (
			post_id BIGINT UNSIGNED NOT NULL,
			post_title TEXT NULL,
			post_url TEXT NULL,
			plain_text LONGTEXT NULL,
			embedding LONGTEXT NULL,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (post_id)
		) {$charset_collate};";

		$sql_sug = "CREATE TABLE {$sug} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			source_post_id BIGINT UNSIGNED NOT NULL,
			source_url TEXT NULL,
			source_title TEXT NULL,
			anchor_text TEXT NULL,
			link TEXT NULL,
			reason TEXT NULL,
			contextual_sentence LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY source_post_id (source_post_id),
			KEY status (status)
		) {$charset_collate};";

		dbDelta( $sql_emb );
		dbDelta( $sql_sug );
	}

	/* ---------- Embeddings ---------- */

	public static function upsert_embedding( $post_id, $title, $url, $plain_text, $embedding_json ) {
		global $wpdb;
		$table = self::embeddings_table();
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$table} (post_id, post_title, post_url, plain_text, embedding, updated_at)
				 VALUES (%d, %s, %s, %s, %s, %s)
				 ON DUPLICATE KEY UPDATE post_title=VALUES(post_title), post_url=VALUES(post_url),
				 plain_text=VALUES(plain_text), embedding=VALUES(embedding), updated_at=VALUES(updated_at)",
				$post_id,
				$title,
				$url,
				$plain_text,
				$embedding_json,
				current_time( 'mysql' )
			)
		);
	}

	/** All embedding rows as assoc arrays. */
	public static function get_all_embeddings() {
		global $wpdb;
		$table = self::embeddings_table();
		return $wpdb->get_results( "SELECT * FROM {$table}", ARRAY_A );
	}

	public static function get_embedding( $post_id ) {
		global $wpdb;
		$table = self::embeddings_table();
		return $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE post_id = %d", $post_id ),
			ARRAY_A
		);
	}

	public static function get_embedded_post_ids() {
		global $wpdb;
		$table = self::embeddings_table();
		return array_map( 'intval', $wpdb->get_col( "SELECT post_id FROM {$table}" ) );
	}

	/* ---------- Suggestions ---------- */

	public static function insert_suggestion( $row ) {
		global $wpdb;
		$wpdb->insert( self::suggestions_table(), $row );
		return $wpdb->insert_id;
	}

	public static function get_suggestion( $id ) {
		global $wpdb;
		$table = self::suggestions_table();
		return $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ),
			ARRAY_A
		);
	}

	public static function get_suggestions( $status = 'pending' ) {
		global $wpdb;
		$table = self::suggestions_table();
		return $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE status = %s ORDER BY created_at DESC", $status ),
			ARRAY_A
		);
	}

	public static function set_suggestion_status( $id, $status ) {
		global $wpdb;
		$wpdb->update( self::suggestions_table(), array( 'status' => $status ), array( 'id' => $id ) );
	}

	/** Post IDs that already have at least one suggestion logged ("Processed Link IDs"). */
	public static function get_processed_post_ids() {
		global $wpdb;
		$table = self::suggestions_table();
		return array_map( 'intval', $wpdb->get_col( "SELECT DISTINCT source_post_id FROM {$table}" ) );
	}
}
