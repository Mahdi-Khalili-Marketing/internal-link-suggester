/* global ILS, jQuery */
( function ( $ ) {
	'use strict';

	function post( action, data ) {
		return $.post(
			ILS.ajaxUrl,
			$.extend( { action: action, nonce: ILS.nonce }, data || {} )
		);
	}

	function setStatus( msg, busy ) {
		var $s = $( '#ils-status' );
		$s.text( msg ).toggleClass( 'ils-busy', !! busy );
	}

	$( function () {
		$( '#ils-sync' ).on( 'click', function () {
			var $btn = $( this ).prop( 'disabled', true );
			setStatus( 'Syncing embeddings…', true );
			post( 'ils_sync_embeddings' )
				.done( function ( r ) {
					setStatus( r && r.data ? r.data.message : 'Done.', false );
				} )
				.fail( function ( x ) {
					setStatus( 'Error: ' + ( x.responseJSON && x.responseJSON.data ? x.responseJSON.data.message : 'request failed' ), false );
				} )
				.always( function () {
					$btn.prop( 'disabled', false );
				} );
		} );

		$( '#ils-find' ).on( 'click', function () {
			var $btn = $( this ).prop( 'disabled', true );
			setStatus( 'Finding suggestions (calling AI)…', true );
			post( 'ils_find_suggestions' )
				.done( function ( r ) {
					setStatus( r && r.data ? r.data.message : 'Done.', false );
					if ( r && r.data && r.data.reload ) {
						window.location.reload();
					}
				} )
				.fail( function ( x ) {
					setStatus( 'Error: ' + ( x.responseJSON && x.responseJSON.data ? x.responseJSON.data.message : 'request failed' ), false );
				} )
				.always( function () {
					$btn.prop( 'disabled', false );
				} );
		} );

		$( '#ils-table' ).on( 'click', '.ils-apply, .ils-dismiss', function () {
			var $btn   = $( this );
			var $row   = $btn.closest( 'tr' );
			var id     = $row.data( 'id' );
			var action = $btn.hasClass( 'ils-apply' ) ? 'ils_apply_suggestion' : 'ils_dismiss_suggestion';

			$row.find( 'button' ).prop( 'disabled', true );
			post( action, { id: id } )
				.done( function ( r ) {
					$row.fadeOut( 200, function () {
						$row.remove();
					} );
					setStatus( r && r.data ? r.data.message : 'Done.', false );
				} )
				.fail( function ( x ) {
					$row.find( 'button' ).prop( 'disabled', false );
					setStatus( 'Error: ' + ( x.responseJSON && x.responseJSON.data ? x.responseJSON.data.message : 'request failed' ), false );
				} );
		} );
	} );
} )( jQuery );
